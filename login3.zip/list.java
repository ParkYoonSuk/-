package com.iot.login3;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import android.util.Log; // 로그 출력 목적
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View; // 뷰계열 최상위 클래스
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import android.content.Intent;
import android.widget.Button;
import android.content.Context;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import android.util.Log; // 로그 출력 목적
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View; // 뷰계열 최상위 클래스
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Date;



public class list extends AppCompatActivity {


    private Button btn_addtext;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);



        btn_addtext = findViewById(R.id.btn_addtext);

        btn_addtext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(list.this, write.class);
                startActivity(intent);

            }
        });

    }
}