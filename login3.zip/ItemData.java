package com.iot.login3;

public class ItemData {
    private long time = 0;

    public long getTime() {
        return time;
    }
    public void setTime(long time) {
        this.time = time;
    }
}
