package com.iot.login3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class write extends AppCompatActivity {
    private ArrayList<String>
            arrayList; private ListView listView;
            private ArrayAdapter<String> adapter;

    private Button btn_reg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write);




        btn_reg = findViewById(R.id.btn_reg);

        btn_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(write.this, list.class);
                startActivity(intent);

                arrayList = new ArrayList<String>();
                for (int i = 0; i > 0; i++)
                    arrayList.add("list" + i);

                listView.setAdapter(adapter);

                Button button = findViewById(R.id.btn_reg);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int number = arrayList.size() + 1;
                        arrayList.add("test" + number);
                        adapter.notifyDataSetChanged();
                        if (number > 0) listView.setSelection(number - 1);

                    }
                });
            }
        });
    }
}